VPN SRY - 5 servers

Upload the five JSON files and subscription.json to a public GitHub repository.
Use subscription.json as the JSON-array subscription endpoint.
